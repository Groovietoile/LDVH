/**
 * 
 */
package Validation;

import Interfaces.IValidation;
import java.util.Set;

/** 
* <!-- begin-UML-doc -->
* <!-- end-UML-doc -->
* @author bapti
* @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
*/
public class GestValidation implements IValidation {
	/** 
	* <!-- begin-UML-doc -->
	* <!-- end-UML-doc -->
	* @param sections
	* @param enchainements
	* @return
	* @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	*/
	public Set<Integer> sectionsInatteignables(Set<Integer> sections, Integer... enchainements) {
		// begin-user-code
		// TODO Auto-generated method stub
		return null;
		// end-user-code
	}

	/** 
	* <!-- begin-UML-doc -->
	* <!-- end-UML-doc -->
	* @return
	* @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	*/
	public Boolean verifGraphe() {
		// begin-user-code
		// TODO Auto-generated method stub
		return null;
		// end-user-code
	}
}