/**
 * 
 */
package testValidation;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.Test;

import Interfaces.IFacade;
import Interfaces.IValidation;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author bapti
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class GestTestValidation {
	
	@Test
	/**
	 * Jeu de donn�es :
	 * - Il y a un livre(titre : "Mon Livre", id : "DUP001", nomAuteur : "Bob Dupont") avec un graphe complet sans sections inatteignables.
	 * @param validation
	 */
	public void nominalGenererImprimable(IValidation validation) {
		assertTrue(validation.verifGraphe());		
	}
	
	@Test
	/**
	 * Jeu de donn�es :
	 * -  Il y a un livre(titre : "Mon Livre2", id : "DUP002", nomAuteur : "Bob Dupont") avec une ou plusieurs sections inatteignables.
	 * @param validation
	 */
	public void E1GenererImprimable(IValidation validation) {
		assertFalse(validation.verifGraphe());		
	}
	
	@Test
	/**
	 * Jeu de donn�es :
	 * - Il y a un livre(titre : "Mon Livre", id : "DUP001", nomAuteur : "Bob Dupont") avec un graphe complet sans sections inatteignables.
	 * @param validation
	 */
	public void nominalGenererHTML(IValidation validation) {
		assertTrue(validation.verifGraphe());		
	}
	
	@Test
	/**
	 * Jeu de donn�es :
	 * -  Il y a un livre(titre : "Mon Livre2", id : "DUP002", nomAuteur : "Bob Dupont") avec une ou plusieurs sections inatteignables.
	 * @param validation
	 */
	public void E1GenererHTML(IValidation validation) {
		assertFalse(validation.verifGraphe());		
	}
	
	@Test
	/**
	 * Jeu de donn�es :
	 * 	- - Un objet livre a �t� cr�� : livre(titre : "Mon Livre", id : "DUP001", nomAuteur : "Bob Dupont");
	 * - Il y a un total de 10 sections, avec les ids allant de 1 � 10.
	 *  - Il y a 7 enchainements.
	 *  - Les sections 3, 6 et 8 sont les seules sections inatteignables.
	 */
	public void nominalVisualiserGraphe(IValidation validation) {
		Set<Integer> sections = new HashSet<>();
		for(int i = 1; i < 11; ++i) sections.add(i);
		
		Set<Integer> resultat = new HashSet<Integer>();
		resultat.add(3);
		resultat.add(6);
		resultat.add(8);
		
		assertEquals(resultat, validation.sectionsInatteignables(sections, 1, 2, 3, 4, 5, 6, 7));
	}
}