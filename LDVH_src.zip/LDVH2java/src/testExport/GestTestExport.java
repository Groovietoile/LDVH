/**
 * 
 */
package testExport;


import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import Interfaces.IExport;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author bapti
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class GestTestExport {
	/*
	Jeu de donn�es:
	- Il y a un livre(titre : "Mon Livre", id : "DUP001", nomAuteur : "Bob Dupont") avec un graphe complet sans sections inatteignables.
	*/
	@Test
	public void nominalExportImprimable(IExport export){
		assertTrue(export.getImprimable());
	}
	
	/*
	Jeu de donn�es:
	- Il y a un livre(titre : "Mon Livre2", id : "DUP002", nomAuteur : "Bob Dupont") avec une ou plusieurs sections inatteignables.
	*/
	@Test
	public void E1ExportImprimable(IExport export){
		assertFalse(export.getImprimable());
	}
	

	
}