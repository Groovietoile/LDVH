/**
 * 
 */
package testLivre;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;

import Interfaces.IEnchainements;
import Interfaces.IFacade;
import Interfaces.ILivres;
import Interfaces.ISections;
import Livre.TypeSection;
import Factory.CompFactory;
/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author bapti
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class GestTestLivre {
	
	@Test
	/**
	 * Les sections avec les ids 1 & 2 existent
	 * @param sections
	 */
	public void testAnnoterEnchainementNominal(IEnchainements enchainements) {
		assertTrue(enchainements.verifDiff(1, 2));
	}
	

	//renvoyer true signifie que l'ID est libre et donc le livre n'existe pas
	public void nominalverifIDlivre(ILivres l){
	    assertTrue(l.verifIDlivre("DUP003"));
	}

	public void A1verifIDlivre(ILivres l){
	    assertFalse(l.verifIDlivre("DUP001"));
	}
	
	/*
	Jeu de donn�es:
	- une section avec un identifiant 1, un type "debut" et un texte "Contenu"
	- un objet d'identifiant "BOU01"
	*/
	@Test
	public void nominalConstruireSection(ISections section){
	  assertTrue(section.verifIDsection(1));
	  assertTrue(section.verifType("debut"));
	  assertTrue(section.verifObjet("BOU01"));
	}

	/*
	Jeu de donn�es:
	- une section avec un identifiant 1 et un type "autre"
	- une section avec un identifiant 1, un type "debut" et un texte "Contenu"
	- un objet d'identifiant "ARC01"
	*/
	@Test
	public void A1ConstruireSection(ISections section){
	  assertFalse(section.verifIDsection(1));
	  assertTrue(section.verifIDsection(2));
	  assertTrue(section.verifType("autre"));
	  assertTrue(section.verifObjet("ARC01"));
	}

	/*
	Jeu de donn�es:
	- une section avec un identifiant 3 et un type "debut"
	- une section avec un identifiant 3, un type "autre" et un texte "Contenu"
	- un objet d'identifiant "EP01"
	*/
	@Test
	public void A2ConstruireSection(ISections section){
	  assertTrue(section.verifIDsection(3));
	  assertFalse(section.verifType("debut"));
	  //assertTrue(section.verifIDsection(3));
	  assertTrue(section.verifType("autre"));
	  assertTrue(section.verifObjet("EP01"));
	}

	/*
	Jeu de donn�es:
	- une section avec un identifiant 4, un type "autre" et un texte "Contenu"
	- un objet d'identifiant "BOU01"
	- un objet d'identifiant "BOU02"
	*/
	@Test
	public void A3ConstruireSection(ISections section){
	  assertTrue(section.verifIDsection(4));
	  assertTrue(section.verifType("autre"));
	  assertFalse(section.verifObjet("BOU01"));
	  assertTrue(section.verifObjet("BOU02"));
	}

	@Test
	/**
	 * Jeu de donn�es :
	 * Les sections 1 & 2 existent.
	 * Il n'y a pas d'enchainement de cr��. 
	 */
	public void nominalDefinirEnchainementSections(IEnchainements enchainements) {
		assertTrue(enchainements.verifDiff(1, 2));
		assertTrue(enchainements.ajouterEnchainement(1, 2) == 1);
	}
	
	@Test
	/**
	 * Jeu de donn�es :
	 * Les sections 1 & 2 existent.
	 * Il n'y a pas d'enchainement de cr��. 
	 */
	public void A1DefinirEnchainementSections(IEnchainements enchainements) {
		assertFalse(enchainements.verifDiff(1, 1));
		assertTrue(enchainements.verifDiff(1, 2));
		assertTrue(enchainements.ajouterEnchainement(1, 2) == 1);
	}
	
	
	@Test
	/**
	 * Jeu de donn�es : 
	 * - Un objet livre a �t� cr�� : livre(titre : "Mon Livre", id : "DUP001", nomAuteur : "Bob Dupont") et il n'y a pas des sections inatteignables.
	 * - Il y a un total de 10 sections, avec les ids allant de 1 � 10.
	 */
	public void nominalGenererImprimable(ISections sections) {
		Set<Integer> sectionsExpected = new HashSet<>();
		for(int i = 1; i < 11; ++i) sectionsExpected.add(i);
		
		assertEquals(sectionsExpected, sections.getSections());
		assertTrue(sections.getText().length() > 0);
	}
	
	@Test
	/**
	 * Jeu de donn�es : 
	 * - Un objet livre a �t� cr�� : livre(titre : "Mon Livre", id : "DUP001", nomAuteur : "Bob Dupont") et il n'y a pas des sections inatteignables.
	 * - Il y a un total de 10 sections, avec les ids allant de 1 � 10.
	 */
	public void nominalGenererHTML(ISections sections) {
		Set<Integer> sectionsExpected = new HashSet<>();
		for(int i = 1; i < 11; ++i) sectionsExpected.add(i);
		
		assertEquals(sectionsExpected, sections.getSections());
	}
	
	@Test
	/**
	 * Jeu de donn�es : 
	 * - Un objet livre a �t� cr�� : livre(titre : "Mon Livre", id : "DUP001", nomAuteur : "Bob Dupont");
	 * - Il y a un total de 10 sections, avec les ids allant de 1 � 10.
	 */
	public void nominalVisualierGraphe(ISections sections, IEnchainements enchainements) {
		Set<Integer> sectionsExpected = new HashSet<>();
		for(int i = 1; i < 11; ++i) sectionsExpected.add(i);
		
		assertEquals(sectionsExpected, sections.getSections());
		
		Set<Integer> enchainementsExpected = new HashSet<>();
		for(int i = 1; i < 7; ++i) enchainementsExpected.add(i);
		assertEquals(enchainementsExpected, enchainements.getEnchainements());
		
	}
	
	@Test
	/**
	 * Jeu de donn�es : 
	 * - Un objet livre a �t� cr�� : livre(titre : "Mon Livre3", id : "DUP003", nomAuteur : "Bob Dupont");
	 * - Il n' y a aucune section de cr��e.
	 */
	public void nominalVisualierGraphe(ISections sections) {
		assertTrue(sections.getSections().size() == 0);
		
	}
	

	
}