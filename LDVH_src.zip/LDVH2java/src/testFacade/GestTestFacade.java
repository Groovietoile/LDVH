/**
 * 
 */
package testFacade;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import Interfaces.IEnchainements;
import Interfaces.IFacade;
import Interfaces.ISections;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class GestTestFacade {
	
	@Test
	public void nominalConstruireSection(IFacade facade){
	  assertTrue(facade.creerSection(1, "debut"));
	  facade.redigerTexte(1, "Contenu");
	  assertTrue(facade.creerObjet(1, "BOU01", "Bouclier"));
	}

	@Test
	public void A1ConstruireSection(IFacade facade){
	  assertFalse(facade.creerSection(1, "autre"));
	  assertTrue(facade.creerSection(2, "autre"));
	  facade.redigerTexte(2, "Contenu");
	  assertTrue(facade.creerObjet(2, "ARC01", "Arc"));
	}
	
	@Test
	public void A2ConstruireSection(IFacade facade){
	  assertFalse(facade.creerSection(3, "debut"));
	  assertTrue(facade.creerSection(3, "autre"));
	  facade.redigerTexte(3, "Contenu");
	  assertTrue(facade.creerObjet(3, "EP01", "Ep�e"));
	}

	@Test
	public void A3ConstruireSection(IFacade facade){
	  assertTrue(facade.creerSection(4, "autre"));
	  facade.redigerTexte(4, "Contenu");
	  assertFalse(facade.creerObjet(4, "BOU01", "Bouclier"));
	  assertTrue(facade.creerObjet(4, "BOU02", "Bouclier"));

	
	}
	
	@Test
	/**
	 * Jeu de donn�es :
	 * L'enchainement avec l'id 1 existe
	 * L'objet avec l'id BOU01 existe
	 * @param facade
	 */
	public void nominalAnnoterEnchainement(IFacade facade){
	  assertTrue(facade.annoterEnchainement(1));
	  assertTrue(facade.ajouterObjetEnchainement(1, "BOU01"));
	}
	
	@Test
	public void nominalCreerLivre(IFacade f){
	    assertTrue(f.creerLivre("DUP001","Mon Livre","Bob Dupont"));
	}
	
	@Test
	public void A1CreerLivre(IFacade f){
	    assertFalse(f.creerLivre("DUP001","Mon Livre2","Bob Dupont"));
	    assertTrue(f.creerLivre("DUP004","Mon Livre2","Bob Dupont"));
	}

	@Test
	public void nominalChargerLivre(IFacade f){
	    assertTrue(f.chargerLivre("DUP001"));
	}

	@Test
	public void A1ChargerLivre(IFacade f){
	    assertFalse(f.chargerLivre("DUP002"));
	    assertTrue(f.chargerLivre("DUP001"));
	}
	
	
	@Test
	/**
	 * Jeu de donn�es : 
	 * Les sections 1 & 2 existent
	 * @param enchainements
	 */
	public void nominalTestDefinirEnchainementSection(IEnchainements enchainements) {
		assertTrue(enchainements.ajouterEnchainement(1, 2) >= 0);
	}
	
	@Test
	/**
	 * Jeu de donn�es : 
	 * Les sections 1 & 2 existent
	 * @param enchainements
	 */
	public void A1TestDefinirEnchainementSection(IEnchainements enchainements) {
		assertFalse(enchainements.ajouterEnchainement(1, 1) < 0);
		assertTrue(enchainements.ajouterEnchainement(1, 2) >= 0);
	}
	
	@Test
	/**
	 * Jeu de donn�es : 
	 * 	- Un objet livre a �t� cr�� : livre(titre : "Mon Livre", id : "DUP001", nomAuteur : "Bob Dupont") et il n'y a pas des sections inatteignables.
	 * @param facade
	 */
	public void nominalExportImprimable(IFacade facade){
	  assertTrue(facade.genererImprimable());
	}
	
	@Test
	/**
	 * Jeu de donn�es : 
	 * 	- Un objet livre a �t� cr�� : livre(titre : "Mon Livre2", id : "DUP002", nomAuteur : "Bob Dupont") mais il contient des sections inatteignables.
	 * @param facade
	 */
	public void E1ExportImprimable(IFacade facade){
	  assertFalse(facade.genererImprimable());
	}
	
	@Test
	/**
	 * Jeu de donn�es : 
	 * 	- Un objet livre a �t� cr�� : livre(titre : "Mon Livre", id : "DUP001", nomAuteur : "Bob Dupont") et il n'y a pas des sections inatteignables.
	 * @param facade
	 */
	public void nominalExportHTML(IFacade facade){
	  assertTrue(facade.genererHTML());
	}
	
	@Test
	/**
	 * Jeu de donn�es : 
	 * 	- Un objet livre a �t� cr�� : livre(titre : "Mon Livre2", id : "DUP002", nomAuteur : "Bob Dupont") mais il contient des sections inatteignables.
	 * @param facade
	 */
	public void E1ExportHTML(IFacade facade){
	  assertFalse(facade.genererHTML());
	}
	
	@Test
	/**
	 * Jeu de donn�es :
	 * - Un objet livre a �t� cr�� : livre(titre : "Mon Livre", id : "DUP001", nomAuteur : "Bob Dupont")
	 * - Il y a un total de 10 sections, avec les ids allant de 1 � 10.
	 */
	public void nominalVisualiserGraphe(IFacade facade) {
		assertTrue(facade.visualiserGraphe());
	}
	
	@Test
	/**
	 * Jeu de donn�es :
	 * 	- Un objet livre a �t� cr�� : livre(titre : "Mon Livre3", id : "DUP003", nomAuteur : "Bob Dupont") mais il n'y a pas de section.
	 */
	public void E1VisualiserGraphe(IFacade facade) {
		assertFalse(facade.visualiserGraphe());
	}
	
	
	

	
	
}


